
Welcome to web2py's API documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 4

   admin
   cache
   cfs
   compileapp
   contenttype
   custom_import
   dal
   debug
   decoder
   fileutils
   globals
   highlight
   html
   http
   languages
   main
   messageboxhandler
   myregex
   newcron
   portalocker
   reserved_sql_keywords
   restricted
   rewrite
   sanitizer
   scheduler
   serializers
   settings
   shell
   sql
   sqlhtml
   storage
   streamer
   template
   tools
   utf8
   utils
   validators
   widget
   xmlrpc



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

