
:mod:`newcron` Module
---------------------

.. automodule:: gluon.newcron
    :members:
    :undoc-members:
    :show-inheritance:
