
:mod:`languages` Module
-----------------------

.. automodule:: gluon.languages
    :members:
    :undoc-members:
    :show-inheritance:
