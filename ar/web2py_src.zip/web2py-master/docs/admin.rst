
:mod:`admin` Module
-------------------

.. automodule:: gluon.admin
    :members:
    :undoc-members:
    :show-inheritance:
