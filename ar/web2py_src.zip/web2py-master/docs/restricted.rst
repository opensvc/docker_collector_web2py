
:mod:`restricted` Module
------------------------

.. automodule:: gluon.restricted
    :members:
    :undoc-members:
    :show-inheritance:
